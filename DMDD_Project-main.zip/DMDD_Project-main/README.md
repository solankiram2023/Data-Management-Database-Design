# DMDD_Project
This repository includes the Project files related to **"Database Management and Database Design".**

**Project Title : City Tram Conveyance Management System**

**Group Members:**
Sriram Raju Venkatesh,
Siddharth Pawar,
Sanal Pillai,
Ramy Solanki,
Rishabh Patel

